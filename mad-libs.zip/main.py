name = input('please enter your name: ')
age = input('please enter your age:')
color= input('please enter your favorite color:')
job = input('please enter your job:')

print('my name is '+ name)
print('and my age is '+ age)
print('my favorite color is '+ color)
print('my job is '+ job)